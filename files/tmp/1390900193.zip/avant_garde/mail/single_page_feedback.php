<?php         
defined('C5_EXECUTE') or die("Access Denied.");

$body = t($name." has sent you feedback for FlexCRETE 
Feedback Type: ".$type." 
Comment: ".$feedback."
Email: ".$email);
?>
